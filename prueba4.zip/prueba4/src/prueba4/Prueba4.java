
package prueba4;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author oscarkevinsanchezgarcia
 */
public class Prueba4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
                   Connection con = DriverManager.getConnection("jdbc:neo4j:bolt://localhost", "neo4j","oliver");
                   try (Statement stmt = con.createStatement()) {
                       ResultSet rs = stmt.executeQuery("MATCH (n:User) RETURN n.name");
                       while (rs.next()) {
                           System.out.println(rs.getString("n.name"));
                           
                           
                       }
                   }
                   con.close();

               }catch (Exception ex){
                   System.out.println("AAA");
               }
    }
    
}
