/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prueba5;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author oscarkevinsanchezgarcia
 */
public class Prueba5 {

    /**
     * @param args the command line arguments
     */
    
    //match(n) optional match(n)-[r]-() delete n,r

    

    public static void main(String[] args) {
        int p12= 3;
    int p13= 2;
    int p19= 6;
    int p114= 1;
    //salidas p2
    int p21= 5;
    int p23= 8;
    int p24= 2;
    int p212= 1;
    //salidas p3
    int p31= 5;
    int p34= 2;
    //salidas p4
    int p45= 5;
    int p46= 7;
    int p411= 2;
    int p413= 3;
    int p414= 7;
    //salidas p5
    int p54= 2;
    int p56= 6;
    int p511= 4;
    int p512= 3;
    int p513= 7;
    int p514= 9;
    //salidas p6
    int p64= 6;
    int p65= 2;
    int p612= 7;
    int p613= 7;
    //salidas p7
    int p78= 12;
    int p79= 13;
    int p711= 1;
    //salidas p8
    int p86= 3;
    int p87= 14;
    int p89= 21;
    int p810= 2;
    //salidas p9
    int p95= 4;
    int p97= 12;
    int p98= 23;
    //salidas p10
    int p1004=9;
    int p1005=7;
    int p1006=1;
    int p1007=1;
    int p1011=5;
    int p1012=4;
    int p1013=8;
    int p1014=7;
    //salidas p11
    int p1104=4;
    int p1106=1;
    int p1110=1;
    int p1113=9;
    int p1114=1;
    //salidas p12
    int p1204=4;
    int p1205=4;
    int p1206=9;
    int p1210=2;
    int p1211=4;
    int p1213=8;
    int p1214=9;
    //salidas p13
    int p1304=1;
    int p1305=3;
    int p1310=2;
    int p1311=3;
    int p1312=3;
    int p1313=2;
    //salidas p14
    int p1404=7;
    int p1410=6;
    int p1411=8;
    int p1412=3;
    
        try {
                   Connection con = DriverManager.getConnection("jdbc:neo4j:bolt://localhost", "neo4j","oliver");
                   
                   try (Statement stmt = con.createStatement()) {
                       //ResultSet rs = stmt.executeQuery("MATCH (n:User) RETURN n.name");
                       ResultSet per1 = stmt.executeQuery("CREATE (p1:Person {name:'per1'})");
                       ResultSet per2 = stmt.executeQuery("CREATE (p2:Person {name:'per2'})");
                       ResultSet per3 = stmt.executeQuery("CREATE (p3:Person {name:'per3'})");
                       ResultSet per4 = stmt.executeQuery("CREATE (p4:Person {name:'per4'})");
                       ResultSet per5 = stmt.executeQuery("CREATE (p5:Person {name:'per5'})");
                       ResultSet per6 = stmt.executeQuery("CREATE (p6:Person {name:'per6'})");
                       ResultSet per7 = stmt.executeQuery("CREATE (p7:Person {name:'per7'})");
                       ResultSet per8 = stmt.executeQuery("CREATE (p8:Person {name:'per8'})");
                       ResultSet per9 = stmt.executeQuery("CREATE (p9:Person {name:'per9'})");
                       ResultSet per10 = stmt.executeQuery("CREATE (p10:Person {name:'per10'})");
                       ResultSet per11 = stmt.executeQuery("CREATE (p11:Person {name:'per11'})");
                       ResultSet per12 = stmt.executeQuery("CREATE (p12:Person {name:'per12'})");
                       ResultSet per13 = stmt.executeQuery("CREATE (p13:Person {name:'per13'})");
                       ResultSet per14 = stmt.executeQuery("CREATE (p14:Person {name:'per14'})");
                       
                    try{
                           stmt.executeUpdate("MATCH (p1:Person {name:'per1'})"+ "MATCH (p2:Person {name:'per2'})" + "MERGE (p1)-[:correos{lenght:"+ p12 +"}]-(p2)");
                           stmt.executeUpdate("MATCH (p1:Person {name:'per1'})"+ "MATCH (p3:Person {name:'per3'})" + "MERGE (p1)-[:correos{lenght:"+p13+"}]-(p3)");
                           stmt.executeUpdate("MATCH (p1:Person {name:'per1'})"+ "MATCH (p3:Person {name:'per3'})" + "MERGE (p1)-[:correos{lenght:"+p13+"}]-(p3)");
                           
                       } catch(SQLException e){
                           e.printStackTrace();
                       }
                       
                   }
                   con.close();

               }catch (Exception ex){
                   System.out.println("error en la conexion con NEO4J");
               }
        
 
        
    }
    
}
